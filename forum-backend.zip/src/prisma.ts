import { PrismaClient } from '../generated/prisma/index.js';

let prisma = new PrismaClient();

export default prisma;